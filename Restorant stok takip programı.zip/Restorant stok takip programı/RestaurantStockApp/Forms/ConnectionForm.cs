using System.Windows.Forms;

namespace RestaurantStockApp.Forms
{
    public class ConnectionForm : Form
    {
        private TextBox _txtServer = null!;
        private TextBox _txtPort = null!;
        private TextBox _txtUser = null!;
        // password removed to allow empty/no-password connections
        private TextBox _txtDatabase = null!;
        private Button _btnOk = null!;
        private Button _btnCancel = null!;

        public string ConnectionString { get; private set; } = string.Empty;

        public ConnectionForm()
        {
            Text = "MySQL Bağlantısı";
            Width = 400;
            Height = 260;
            StartPosition = FormStartPosition.CenterScreen;
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            var lblServer = new Label { Text = "Server:", Left = 10, Top = 10, Width = 80 };
            _txtServer = new TextBox { Left = 100, Top = 10, Width = 260, Text = "localhost" };

            var lblPort = new Label { Text = "Port:", Left = 10, Top = 40, Width = 80 };
            _txtPort = new TextBox { Left = 100, Top = 40, Width = 260, Text = "3306" };

            var lblUser = new Label { Text = "User:", Left = 10, Top = 70, Width = 80 };
            _txtUser = new TextBox { Left = 100, Top = 70, Width = 260, Text = "root" };

            var lblDb = new Label { Text = "Database:", Left = 10, Top = 100, Width = 80 };
            _txtDatabase = new TextBox { Left = 100, Top = 100, Width = 260, Text = "restoran" };

            _btnOk = new Button { Text = "Bağlan", Left = 200, Width = 80, Top = 140, DialogResult = DialogResult.OK };
            _btnCancel = new Button { Text = "İptal", Left = 290, Width = 80, Top = 170, DialogResult = DialogResult.Cancel };

            _btnOk.Click += BtnOk_Click;

            Controls.Add(lblServer);
            Controls.Add(_txtServer);
            Controls.Add(lblPort);
            Controls.Add(_txtPort);
            Controls.Add(lblUser);
            Controls.Add(_txtUser);
            Controls.Add(lblDb);
            Controls.Add(_txtDatabase);
            Controls.Add(_btnOk);
            Controls.Add(_btnCancel);

            AcceptButton = _btnOk;
            CancelButton = _btnCancel;
        }

        private void BtnOk_Click(object? sender, System.EventArgs e)
        {
            var server = _txtServer.Text.Trim();
            var port = _txtPort.Text.Trim();
            var user = _txtUser.Text.Trim();
            // password intentionally optional/omitted
            var pass = string.Empty;
            var db = _txtDatabase.Text.Trim();

            if (string.IsNullOrWhiteSpace(server) || string.IsNullOrWhiteSpace(port) || string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(db))
            {
                MessageBox.Show("Lütfen tüm alanları doldurun.", "Eksik Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.DialogResult = DialogResult.None;
                return;
            }

            ConnectionString = $"server={server};port={port};user={user};password={pass};database={db};";
            // DialogResult remains OK and form will close
        }
    }
}
