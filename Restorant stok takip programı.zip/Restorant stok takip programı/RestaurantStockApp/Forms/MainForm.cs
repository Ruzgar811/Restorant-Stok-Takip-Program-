using System.Drawing;
using System.Windows.Forms;
using System.Linq;
using RestaurantStockApp.Models;
using MySqlConnector;
using RestaurantStockApp.Services;

namespace RestaurantStockApp.Forms
{
    public class MainForm : Form
    {
        private readonly IInventoryService _svc;
        private SplitContainer _split = null!;
        private ListBox _lbCategories = null!;
        private TextBox _txtCategorySearch = null!;
        private DataGridView _dgvProducts = null!;
        private TextBox _txtProductSearch = null!;
        private TextBox txtUrunAdi = null!;
        private TextBox txtAdet = null!;
        private TextBox txtFiyat = null!;
        private Button btnKaydet = null!;
        private Button _btnAddCategory = null!;
        private Button _btnRemoveCategory = null!;
        private Button _btnAddProduct = null!;
        private Button _btnRemoveProduct = null!;
        private Button _btnIncreaseQty = null!;
        private Button _btnBaglan = null!;
        private double _splitRatio = 0.45; // left panel ratio (smaller so product area visible on small screens)
        private List<string> _allCategories = new();
        private List<Product> _currentProducts = new();
        private bool _suspendSelectionSync = false;
        private const string CategoryHint = "Kategori ara...";
        private const string ProductHint = "Ürün ara...";
        // default bağlantı dizesi (kullanıcı istediği gibi değiştirebilir)
        private string baglanti = "Server=localhost;Port=3306;Database=restorantstokdb;Uid=root;Pwd=;";

        public MainForm(IInventoryService svc)
        {
            _svc = svc;
            Text = "Restoran Stok Takip";
            Width = 800;
            Height = 600;
            InitializeComponents();
            LoadCategories();
            // keep a reasonable minimum size and maintain splitter ratio on resize
            MinimumSize = new Size(640, 360);
            this.Resize += MainForm_Resize;
            _split.SplitterMoved += (s, e) => { if (ClientSize.Width > 0) _splitRatio = (double)_split.SplitterDistance / ClientSize.Width; };
            // apply initial splitter ratio
            _split.Panel1MinSize = 120;
            _split.Panel2MinSize = 260;
            _split.SplitterDistance = Math.Max(120, (int)(_splitRatio * this.ClientSize.Width));
        }

        private void btnKaydet_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUrunAdi.Text) ||
                !int.TryParse(txtAdet.Text, out int adet) ||
                !decimal.TryParse(
                    txtFiyat.Text,
                    System.Globalization.NumberStyles.Number,
                    System.Globalization.CultureInfo.GetCultureInfo("tr-TR"),
                    out decimal fiyat))
            {
                MessageBox.Show("Ürün adı, adet ve fiyatı kontrol et.");
                return;
            }

            if (adet < 0 || fiyat < 0)
            {
                MessageBox.Show("Adet ve fiyat negatif olamaz.");
                return;
            }

            try
            {
                using (var conn = new MySqlConnection(baglanti))
                {
                    conn.Open();

                    string sql = @"INSERT INTO Urunler
                           (UrunAdi, Adet, Fiyat)
                           VALUES (@ad, @adet, @fiyat)";

                    using (var cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@ad", txtUrunAdi.Text.Trim());
                        cmd.Parameters.AddWithValue("@adet", adet);
                        cmd.Parameters.AddWithValue("@fiyat", fiyat);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Ürün başarıyla kaydedildi!");

                txtUrunAdi.Clear();
                txtAdet.Clear();
                txtFiyat.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kayıt hatası: " + ex.Message);
            }
        }

        // MySQL bağlantı butonu işlemi
        private void btnBaglan_Click(object? sender, EventArgs e)
        {
            try
            {
                using (var conn = new MySqlConnection(baglanti))
                {
                    conn.Open();
                    MessageBox.Show("MySQL bağlantısı başarılı!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bağlantı hatası: " + ex.Message);
            }
        }

        // Dialog to add quantity for a product. It returns the new total quantity in Amount.
        private class QuantityDialog : Form
        {
            private NumericUpDown _numPieces;
            private NumericUpDown _numKg;
            private Button _ok;
            private Button _cancel;
            public int AmountPieces { get; private set; }
            public int AmountKg { get; private set; }
            public QuantityDialog(Product p)
            {
                Text = "Miktar Ekle";
                Width = 420; Height = 200; StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
                var lbl = new Label { Text = $"Ürün: {p.Name} (Mevcut: {p.QuantityPieces} adet, {p.QuantityKg} kg)", Dock = DockStyle.Top, Height = 28 };
                var lblPieces = new Label { Text = "Eklenecek adet:", Dock = DockStyle.Top, Height = 18 };
                _numPieces = new NumericUpDown { Minimum = 0, Maximum = 1000000, Value = 0, Dock = DockStyle.Top };
                var lblKg = new Label { Text = "Eklenecek kilogram:", Dock = DockStyle.Top, Height = 18 };
                _numKg = new NumericUpDown { Minimum = 0, Maximum = 1000000, Value = 0, Dock = DockStyle.Top };
                var pnl = new Panel { Dock = DockStyle.Bottom, Height = 40 };
                _ok = new Button { Text = "Tamam", DialogResult = DialogResult.OK, Left = 220, Width = 70, Top = 6 };
                _cancel = new Button { Text = "İptal", DialogResult = DialogResult.Cancel, Left = 300, Width = 70, Top = 6 };
                pnl.Controls.Add(_ok); pnl.Controls.Add(_cancel);
                Controls.Add(_numKg); Controls.Add(lblKg); Controls.Add(_numPieces); Controls.Add(lblPieces); Controls.Add(lbl); Controls.Add(pnl);
                AcceptButton = _ok; CancelButton = _cancel;
                _ok.Click += (s, e) => { AmountPieces = (int)_numPieces.Value; AmountKg = (int)_numKg.Value; };
            }
        }

        private void BtnIncreaseQty_Click(object? sender, EventArgs e)
        {
            if (_dgvProducts.SelectedRows.Count == 0) { MessageBox.Show("Önce ürün seçin."); return; }
            var idCell = _dgvProducts.SelectedRows[0].Cells["Id"].Value?.ToString();
            if (string.IsNullOrEmpty(idCell) || !Guid.TryParse(idCell, out var id)) { MessageBox.Show("Geçersiz ürün seçimi."); return; }
            var p = _svc.Get(id);
            if (p is null) { MessageBox.Show("Ürün bulunamadı."); return; }

            var dlg = new QuantityDialog(p);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                if (_svc.UpdateQuantity(p.Id, dlg.AmountPieces, dlg.AmountKg)) LoadProductsForSelectedCategory();
                else MessageBox.Show("Miktar güncellenemedi.");
            }
        }

        private void MainForm_Resize(object? sender, EventArgs e)
        {
            if (ClientSize.Width <= 0) return;
            var min = 150;
            var max = Math.Max(min, ClientSize.Width - min);
            var desired = (int)(_splitRatio * ClientSize.Width);
            _split.SplitterDistance = Math.Clamp(desired, min, max);
        }



        private void InitializeComponents()
        {
            _split = new SplitContainer { Dock = DockStyle.Fill, SplitterDistance = 200 };

            // Left - categories using TableLayoutPanel for reliable layout on small screens
            var leftTable = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1 };
            leftTable.RowCount = 3;
            leftTable.RowStyles.Clear();
            leftTable.RowStyles.Add(new RowStyle(SizeType.AutoSize)); // search
            leftTable.RowStyles.Add(new RowStyle(SizeType.AutoSize)); // buttons
            leftTable.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); // list fills remaining space

            _txtCategorySearch = new TextBox { Dock = DockStyle.Fill, Height = 26, Text = CategoryHint, ForeColor = SystemColors.GrayText };
            _txtCategorySearch.GotFocus += (s, e) => { if (_txtCategorySearch.Text == CategoryHint) { _txtCategorySearch.Text = ""; _txtCategorySearch.ForeColor = SystemColors.WindowText; } };
            _txtCategorySearch.LostFocus += (s, e) => { if (string.IsNullOrWhiteSpace(_txtCategorySearch.Text)) { _txtCategorySearch.Text = CategoryHint; _txtCategorySearch.ForeColor = SystemColors.GrayText; } };
            _txtCategorySearch.TextChanged += (s, e) => FilterCategories();

            var btnPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, Height = 36, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, Padding = new Padding(4) };
            _btnAddCategory = new Button { Text = "Kategori Ekle", AutoSize = true };
            _btnRemoveCategory = new Button { Text = "Kategori Sil", AutoSize = true };
            _btnAddCategory.Click += BtnAddCategory_Click;
            _btnRemoveCategory.Click += BtnRemoveCategory_Click;
            btnPanel.Controls.Add(_btnAddCategory);
            btnPanel.Controls.Add(_btnRemoveCategory);

            _lbCategories = new ListBox { Dock = DockStyle.Fill };
            _lbCategories.SelectedIndexChanged += (s, e) => LoadProductsForSelectedCategory();

            leftTable.Controls.Add(_txtCategorySearch, 0, 0);
            leftTable.Controls.Add(btnPanel, 0, 1);
            leftTable.Controls.Add(_lbCategories, 0, 2);

            _split.Panel1.Controls.Add(leftTable);

            // Right - products
            var rightPanel = new Panel { Dock = DockStyle.Fill };
            _txtProductSearch = new TextBox { Dock = DockStyle.Top, Height = 22, Text = ProductHint, ForeColor = SystemColors.GrayText };
            _txtProductSearch.GotFocus += (s, e) => { if (_txtProductSearch.Text == ProductHint) { _txtProductSearch.Text = ""; _txtProductSearch.ForeColor = SystemColors.WindowText; } };
            _txtProductSearch.LostFocus += (s, e) => { if (string.IsNullOrWhiteSpace(_txtProductSearch.Text)) { _txtProductSearch.Text = ProductHint; _txtProductSearch.ForeColor = SystemColors.GrayText; } };
            _txtProductSearch.TextChanged += (s, e) => FilterProducts();

            // Create DataGridView to show products in columns: Ürün | Adet | Kilogram
            _dgvProducts = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                RowHeadersVisible = false,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            // Id hidden column for mapping
            var colId = new DataGridViewTextBoxColumn { Name = "Id", Visible = false };
            var colName = new DataGridViewTextBoxColumn { Name = "Ürün", HeaderText = "Ürün" };
            var colAdet = new DataGridViewTextBoxColumn { Name = "Adet", HeaderText = "Adet", FillWeight = 20 };
            var colKg = new DataGridViewTextBoxColumn { Name = "Kilogram", HeaderText = "Kilogram", FillWeight = 20 };
            _dgvProducts.Columns.AddRange(new DataGridViewColumn[] { colId, colName, colAdet, colKg });
            _dgvProducts.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) _btnIncreaseQty.PerformClick(); };

            // small input panel for quick product add
            var inputPanel = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 36, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, Padding = new Padding(4) };
            txtUrunAdi = new TextBox { Width = 160, PlaceholderText = "Ürün adı" };
            txtAdet = new TextBox { Width = 60, PlaceholderText = "Adet" };
            txtFiyat = new TextBox { Width = 80, PlaceholderText = "Fiyat" };
            btnKaydet = new Button { Text = "Kaydet" };
            btnKaydet.Click += btnKaydet_Click;
            inputPanel.Controls.Add(txtUrunAdi);
            inputPanel.Controls.Add(txtAdet);
            inputPanel.Controls.Add(txtFiyat);
            inputPanel.Controls.Add(btnKaydet);

            var prodButtons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 36, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, Padding = new Padding(4) };
            _btnAddProduct = new Button { Text = "Ürün Ekle" };
            _btnIncreaseQty = new Button { Text = "Adet Ekle" };
            _btnRemoveProduct = new Button { Text = "Ürün Sil" };
            _btnBaglan = new Button { Text = "Bağlan", Name = "btnBaglan" };
            _btnAddProduct.AutoSize = true; _btnIncreaseQty.AutoSize = true; _btnRemoveProduct.AutoSize = true;
            _btnAddProduct.Click += BtnAddProduct_Click;
            _btnIncreaseQty.Click += BtnIncreaseQty_Click;
            _btnRemoveProduct.Click += BtnRemoveProduct_Click;
            _btnBaglan.Click += btnBaglan_Click;
            prodButtons.Controls.Add(_btnAddProduct);
            prodButtons.Controls.Add(_btnIncreaseQty);
            prodButtons.Controls.Add(_btnRemoveProduct);
            prodButtons.Controls.Add(_btnBaglan);

            // add product DataGridView (Fill), then search (Top), input panel (Bottom) and buttons (Bottom)
            // so Top/Bottom docked controls are visible above the Fill panel
            rightPanel.Controls.Add(_dgvProducts);
            rightPanel.Controls.Add(_txtProductSearch);
            rightPanel.Controls.Add(inputPanel);
            rightPanel.Controls.Add(prodButtons);
            _split.Panel2.Controls.Add(rightPanel);
            Controls.Add(_split);
        }

        private void LoadCategories()
        {
            _allCategories = _svc.GetAllCategories();
            ApplyCategoryFilter();
            if (_lbCategories.Items.Count > 0) _lbCategories.SelectedIndex = 0;
        }

        private void ApplyCategoryFilter()
        {
            string raw = _txtCategorySearch.Text.Trim();
            string q = raw.Equals(CategoryHint, StringComparison.CurrentCultureIgnoreCase) ? "" : raw.ToLower();
            _lbCategories.BeginUpdate();
            _lbCategories.Items.Clear();
            for (int i = 0; i < _allCategories.Count; i++)
            {
                string c = _allCategories[i];
                if (q == "" || c.ToLower().Contains(q))
                {
                    _lbCategories.Items.Add(c);
                }
            }
            _lbCategories.EndUpdate();
        }

        private void FilterCategories() => ApplyCategoryFilter();

        private void LoadProductsForSelectedCategory()
        {
            if (!(_lbCategories.SelectedItem is string category)) return;
            _currentProducts = _svc.GetProductsByCategory(category);
            ApplyProductFilter();
        }

        private void ApplyProductFilter()
        {
            string raw = _txtProductSearch.Text.Trim();
            string q = raw.Equals(ProductHint, StringComparison.CurrentCultureIgnoreCase) ? "" : raw.ToLower();
            _dgvProducts.Rows.Clear();
            for (int i = 0; i < _currentProducts.Count; i++)
            {
                var p = _currentProducts[i];
                if (q == "" || p.Name.ToLower().Contains(q))
                {
                    var adetVal = p.QuantityPieces > 0 ? p.QuantityPieces.ToString() : "";
                    var kgVal = p.QuantityKg > 0 ? p.QuantityKg.ToString() : "";
                    _dgvProducts.Rows.Add(p.Id.ToString(), p.Name, adetVal, kgVal);
                }
            }
        }

        // placeholder kept for compatibility; DataGridView handles selection now
        private void ProdList_SelectedIndexChanged(object? sender, EventArgs e) { }

        private void FilterProducts() => ApplyProductFilter();

        private void BtnAddCategory_Click(object? sender, EventArgs e)
        {
            var input = Prompt.ShowDialog("Yeni kategori adı:", "Kategori Ekle");
            if (string.IsNullOrWhiteSpace(input)) return;
            if (_svc.AddCategory(input)) LoadCategories();
            else MessageBox.Show("Kategori eklenemedi (zaten var veya geçersiz).", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void BtnRemoveCategory_Click(object? sender, EventArgs e)
        {
            if (_lbCategories.SelectedItem is not string category) return;
            var ok = MessageBox.Show($"'{category}' kategorisini silmek istediğinize emin misiniz? Bu kategoriye ait ürünler de silinecek.", "Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (ok != DialogResult.Yes) return;
            if (_svc.RemoveCategory(category)) LoadCategories();
            else MessageBox.Show("Kategori silinemedi.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void BtnAddProduct_Click(object? sender, EventArgs e)
        {
            if (_lbCategories.SelectedItem is not string category) { MessageBox.Show("Önce kategori seçin."); return; }
            var name = Prompt.ShowDialog("Ürün adı:", "Ürün Ekle");
            if (string.IsNullOrWhiteSpace(name)) return;
            // ask separately for adet and kilogram
            var piecesText = Prompt.ShowDialog("Adet (tam sayı):", "Ürün Ekle", "0");
            if (!int.TryParse(piecesText, out var pieces)) pieces = 0;
            var kgText = Prompt.ShowDialog("Kilogram (tam sayı):", "Ürün Ekle", "0");
            if (!int.TryParse(kgText, out var kgs)) kgs = 0;
            var p = new Product { Name = name, QuantityPieces = pieces, QuantityKg = kgs, Category = category };
            _svc.AddProduct(p);
            LoadProductsForSelectedCategory();
        }

        private void BtnRemoveProduct_Click(object? sender, EventArgs e)
        {
            if (_dgvProducts.SelectedRows.Count == 0) return;
            var idCell = _dgvProducts.SelectedRows[0].Cells["Id"].Value?.ToString();
            if (string.IsNullOrEmpty(idCell) || !Guid.TryParse(idCell, out var id)) return;
            var confirm = MessageBox.Show("Seçili ürünü silmek istiyor musunuz?", "Sil", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm == DialogResult.Yes)
            {
                if (_svc.RemoveProduct(id)) LoadProductsForSelectedCategory();
                else MessageBox.Show("Ürün silinemedi.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Simple prompt helper
        private class Prompt : Form
        {
            private TextBox _txt;
            private Button _ok;
            private Button _cancel;
            public static string ShowDialog(string text, string caption, string defaultValue = "")
            {
                using var dlg = new Prompt(text, caption, defaultValue);
                return dlg.ShowDialog() == DialogResult.OK ? dlg._txt.Text : string.Empty;
            }

            private Prompt(string text, string caption, string defaultValue)
            {
                Text = caption;
                Width = 400; Height = 140; StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
                var lbl = new Label { Text = text, Dock = DockStyle.Top, Height = 20 };
                _txt = new TextBox { Text = defaultValue, Dock = DockStyle.Top }; _txt.SelectAll();
                var pnl = new Panel { Dock = DockStyle.Bottom, Height = 40 };
                _ok = new Button { Text = "Tamam", DialogResult = DialogResult.OK, Left = 220, Width = 70, Top = 6 };
                _cancel = new Button { Text = "İptal", DialogResult = DialogResult.Cancel, Left = 300, Width = 70, Top = 6 };
                pnl.Controls.Add(_ok); pnl.Controls.Add(_cancel);
                Controls.Add(_txt); Controls.Add(lbl); Controls.Add(pnl);
                AcceptButton = _ok; CancelButton = _cancel;
            }
        }
    }
}
