namespace RestaurantStockApp.Models
{
    public class Product
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Name { get; set; } = string.Empty;
        // Separate quantity fields: pieces and kilograms
        public int QuantityPieces { get; set; }
        public decimal QuantityKg { get; set; }
        public string Category { get; set; } = string.Empty;
        public decimal PurchasePrice { get; set; }
        public decimal? SellPrice { get; set; }
    }
}
