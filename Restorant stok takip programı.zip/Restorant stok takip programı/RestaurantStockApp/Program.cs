using System;
using System.IO;
using System;
using System.IO;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using RestaurantStockApp.Services;
using RestaurantStockApp.Forms;

ApplicationConfiguration.Initialize();

// Basit versiyon: JSON dosyası kullanıyoruz. inventory.json uygulama klasöründe saklanır.
var dataFile = Path.Combine(AppContext.BaseDirectory, "inventory.json");
try
{
    // Default to MySQL using database name 'restorantstokdb' on local XAMPP.
    // If MySQL is not available or connection fails, fall back to JSON file.
    var defaultConn = "Server=localhost;Port=3306;Database=restorantstokdb;Uid=root;Pwd=;";
    var mysql = Environment.GetEnvironmentVariable("MYSQL_CONN");
    var connStr = string.IsNullOrWhiteSpace(mysql) ? defaultConn : mysql;
    try
    {
        var svc = new MySqlInventoryService(connStr);
        // quick connectivity test
        svc.GetAllCategories();
        Application.Run(new MainForm(svc));
    }
    catch
    {
        // fallback to JSON-based service if MySQL unavailable
        var svc = new InventoryService(dataFile);
        MessageBox.Show("MySQL bağlantısı kurulamadı; JSON modu ile başlatılıyor.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        Application.Run(new MainForm(svc));
    }
}
catch (Exception ex)
{
    MessageBox.Show($"Başlatma sırasında hata oluştu:\n{ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
}
