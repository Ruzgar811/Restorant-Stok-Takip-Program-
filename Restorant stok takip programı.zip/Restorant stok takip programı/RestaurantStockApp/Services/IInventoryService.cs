using System;
using System.Collections.Generic;
using RestaurantStockApp.Models;

namespace RestaurantStockApp.Services
{
    public interface IInventoryService
    {
        List<string> GetAllCategories();
        bool AddCategory(string category);
        bool RemoveCategory(string category);

        List<Product> GetProductsByCategory(string category);
        Product? Get(Guid id);
        void AddProduct(Product product);
        bool RemoveProduct(Guid id);
        // addPieces and addKg are deltas to apply
        bool UpdateQuantity(Guid id, int addPieces, int addKg);
    }
}
