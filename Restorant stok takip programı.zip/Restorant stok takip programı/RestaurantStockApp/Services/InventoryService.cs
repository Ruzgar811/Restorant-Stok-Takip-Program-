using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using RestaurantStockApp.Models;

namespace RestaurantStockApp.Services
{
    // Basit JSON tabanlı stok servisi - 11. sınıf düzeyi için sadeleştirildi
    public class InventoryService : IInventoryService
    {
        private readonly string _filePath;
        private readonly List<Product> _products = new();
        private readonly List<string> _categories = new();

        public InventoryService(string filePath)
        {
            _filePath = filePath;
            Load();

            if (_categories.Count == 0)
            {
                // bazı örnek kategoriler
                _categories.Add("Sebzeler");
                _categories.Add("Meyveler");
                _categories.Add("Kırmızı Et");
                _categories.Add("Beyaz Et");
                _categories.Add("Süt Ürünleri");
                _categories.Add("İçecekler");
            }

            if (_products.Count == 0)
            {
                // örnek ürünler (Id atanıyor) - artık ayrı adet ve kilogram alanları var
                _products.Add(new Product { Id = Guid.NewGuid(), Name = "Domates", QuantityPieces = 10, QuantityKg = 5, Category = "Sebzeler" });
                _products.Add(new Product { Id = Guid.NewGuid(), Name = "Marul", QuantityPieces = 20, QuantityKg = 9, Category = "Sebzeler" });
                _products.Add(new Product { Id = Guid.NewGuid(), Name = "Elma", QuantityPieces = 0, QuantityKg = 15, Category = "Meyveler" });
            }

            Save();
        }

        private void Load()
        {
            try
            {
                if (!File.Exists(_filePath)) return;
                var text = File.ReadAllText(_filePath);
                var doc = JsonSerializer.Deserialize<InventoryData>(text);
                if (doc == null) return;
                _categories.Clear();
                _categories.AddRange(doc.Categories ?? new List<string>());
                _products.Clear();
                _products.AddRange(doc.Products ?? new List<Product>());
            }
            catch
            {
                // basit versiyon: hataları yoksay
            }
        }

        private void Save()
        {
            try
            {
                var doc = new InventoryData
                {
                    Categories = new List<string>(_categories),
                    Products = new List<Product>(_products)
                };
                var text = JsonSerializer.Serialize(doc, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(_filePath, text);
            }
            catch
            {
                // basit versiyon: hataları yoksay
            }
        }

        public List<string> GetAllCategories()
        {
            return new List<string>(_categories);
        }

        public bool AddCategory(string category)
        {
            if (string.IsNullOrWhiteSpace(category)) return false;
            if (_categories.Contains(category)) return false;
            _categories.Add(category);
            Save();
            return true;
        }

        public bool RemoveCategory(string category)
        {
            if (!_categories.Contains(category)) return false;
            // bu kategoriye ait ürünleri sil
            for (int i = _products.Count - 1; i >= 0; i--)
            {
                if (string.Equals(_products[i].Category, category, StringComparison.Ordinal)) _products.RemoveAt(i);
            }
            _categories.Remove(category);
            Save();
            return true;
        }

        public List<Product> GetProductsByCategory(string category)
        {
            var result = new List<Product>();
            foreach (var p in _products)
            {
                if (string.Equals(p.Category, category, StringComparison.Ordinal)) result.Add(p);
            }
            return result;
        }

        public Product? Get(Guid id)
        {
            foreach (var p in _products)
            {
                if (p.Id == id) return p;
            }
            return null;
        }

        public void AddProduct(Product product)
        {
            if (product == null) return;
            if (product.Id == Guid.Empty) product.Id = Guid.NewGuid();
            if (string.IsNullOrWhiteSpace(product.Category) == false && !_categories.Contains(product.Category))
            {
                _categories.Add(product.Category);
            }
            _products.Add(product);
            Save();
        }

        public bool RemoveProduct(Guid id)
        {
            for (int i = 0; i < _products.Count; i++)
            {
                if (_products[i].Id == id)
                {
                    _products.RemoveAt(i);
                    Save();
                    return true;
                }
            }
            return false;
        }

        // addPieces and addKg are amounts to add (can be zero)
        public bool UpdateQuantity(Guid id, int addPieces, int addKg)
        {
            foreach (var p in _products)
            {
                if (p.Id == id)
                {
                    p.QuantityPieces += addPieces;
                    p.QuantityKg += addKg;
                    Save();
                    return true;
                }
            }
            return false;
        }
    }

    // Basit veri taşıyıcı sınıfı
    internal class InventoryData
    {
        public List<string> Categories { get; set; } = new();
        public List<Product> Products { get; set; } = new();
    }
}
