using System;
using System.Collections.Generic;
using MySqlConnector;
using RestaurantStockApp.Models;

namespace RestaurantStockApp.Services
{
    public class MySqlInventoryService : IInventoryService
    {
        private readonly string _cs;
        public MySqlInventoryService(string connectionString) => _cs = connectionString;

        public List<string> GetAllCategories()
        {
            var list = new List<string>();
            using var c = new MySqlConnection(_cs);
            c.Open();
            using var cmd = new MySqlCommand("SELECT DISTINCT Category FROM products", c);
            using var rdr = cmd.ExecuteReader();
            while (rdr.Read()) list.Add(rdr.GetString(0));
            return list;
        }

        public List<Product> GetProductsByCategory(string category)
        {
            var list = new List<Product>();
            using var c = new MySqlConnection(_cs);
            c.Open();
            using var cmd = new MySqlCommand("SELECT Id, Name, Category, QuantityPieces, QuantityKg, PurchasePrice, SellPrice FROM products WHERE Category = @cat", c);
            cmd.Parameters.AddWithValue("@cat", category);
            using var rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                list.Add(new Product {
                    Id = Guid.Parse(rdr.GetString("Id")),
                    Name = rdr.GetString("Name"),
                    Category = rdr.GetString("Category"),
                    QuantityPieces = rdr.IsDBNull(rdr.GetOrdinal("QuantityPieces")) ? 0 : rdr.GetInt32("QuantityPieces"),
                    QuantityKg = rdr.IsDBNull(rdr.GetOrdinal("QuantityKg")) ? 0 : rdr.GetInt32("QuantityKg"),
                    PurchasePrice = rdr.IsDBNull(rdr.GetOrdinal("PurchasePrice")) ? 0m : rdr.GetDecimal("PurchasePrice"),
                    SellPrice = rdr.IsDBNull(rdr.GetOrdinal("SellPrice")) ? 0m : rdr.GetDecimal("SellPrice")
                });
            }
            return list;
        }

        public Product? Get(Guid id)
        {
            using var c = new MySqlConnection(_cs);
            c.Open();
            using var cmd = new MySqlCommand("SELECT Id, Name, Category, QuantityPieces, QuantityKg, PurchasePrice, SellPrice FROM products WHERE Id = @id", c);
            cmd.Parameters.AddWithValue("@id", id.ToString());
            using var rdr = cmd.ExecuteReader();
            if (!rdr.Read()) return null;
            return new Product {
                Id = Guid.Parse(rdr.GetString("Id")),
                Name = rdr.GetString("Name"),
                Category = rdr.GetString("Category"),
                QuantityPieces = rdr.IsDBNull(rdr.GetOrdinal("QuantityPieces")) ? 0 : rdr.GetInt32("QuantityPieces"),
                QuantityKg = rdr.IsDBNull(rdr.GetOrdinal("QuantityKg")) ? 0 : rdr.GetInt32("QuantityKg"),
                PurchasePrice = rdr.IsDBNull(rdr.GetOrdinal("PurchasePrice")) ? 0m : rdr.GetDecimal("PurchasePrice"),
                SellPrice = rdr.IsDBNull(rdr.GetOrdinal("SellPrice")) ? 0m : rdr.GetDecimal("SellPrice")
            };
        }

        public void AddProduct(Product p)
        {
            using var c = new MySqlConnection(_cs);
            c.Open();
            using var cmd = new MySqlCommand(@"INSERT INTO products (Id, Name, Category, QuantityPieces, QuantityKg, PurchasePrice, SellPrice)
                                              VALUES (@id,@name,@cat,@pieces,@kgs,@buy,@sell)", c);
            cmd.Parameters.AddWithValue("@id", p.Id == Guid.Empty ? Guid.NewGuid().ToString() : p.Id.ToString());
            cmd.Parameters.AddWithValue("@name", p.Name);
            cmd.Parameters.AddWithValue("@cat", p.Category);
            cmd.Parameters.AddWithValue("@pieces", p.QuantityPieces);
            cmd.Parameters.AddWithValue("@kgs", p.QuantityKg);
            cmd.Parameters.AddWithValue("@buy", p.PurchasePrice);
            cmd.Parameters.AddWithValue("@sell", p.SellPrice);
            cmd.ExecuteNonQuery();
        }

        public bool RemoveProduct(Guid id)
        {
            using var c = new MySqlConnection(_cs);
            c.Open();
            using var cmd = new MySqlCommand("DELETE FROM products WHERE Id = @id", c);
            cmd.Parameters.AddWithValue("@id", id.ToString());
            return cmd.ExecuteNonQuery() > 0;
        }

        public bool UpdateQuantity(Guid id, int addPieces, int addKg)
        {
            using var c = new MySqlConnection(_cs);
            c.Open();
            using var cmd = new MySqlCommand(@"UPDATE products
                                              SET QuantityPieces = QuantityPieces + @addPieces,
                                                  QuantityKg = QuantityKg + @addKg
                                              WHERE Id = @id", c);
            cmd.Parameters.AddWithValue("@addPieces", addPieces);
            cmd.Parameters.AddWithValue("@addKg", addKg);
            cmd.Parameters.AddWithValue("@id", id.ToString());
            return cmd.ExecuteNonQuery() > 0;
        }

        public bool AddCategory(string category)
        {
            // Ensure category exists by inserting a dummy product? Simpler: no-op and return true
            // Caller will reload categories from products table. For now return true.
            return true;
        }

        public bool RemoveCategory(string category)
        {
            using var c = new MySqlConnection(_cs);
            c.Open();
            using var cmd = new MySqlCommand("DELETE FROM products WHERE Category = @cat", c);
            cmd.Parameters.AddWithValue("@cat", category);
            cmd.ExecuteNonQuery();
            return true;
        }
    }
}
