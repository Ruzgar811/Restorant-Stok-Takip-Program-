using RestaurantStockApp.Forms;
using RestaurantStockApp.Services;
using System.Windows.Forms;

namespace Restorant_stok_takip_programı
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            // Try environment variable or conn.txt, else default. No interactive dialog.
            var conn = Environment.GetEnvironmentVariable("RESTORANT_CONN");
            if (string.IsNullOrWhiteSpace(conn))
            {
                var path = Path.Combine(AppContext.BaseDirectory, "conn.txt");
                if (File.Exists(path)) conn = File.ReadAllText(path).Trim();
            }
            if (string.IsNullOrWhiteSpace(conn)) conn = "server=localhost;port=3306;user=root;password=;database=restoran;";
            try
            {
                var svc = new InventoryService(conn);
                Application.Run(new RestaurantStockApp.Forms.MainForm(svc));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Veritabanına bağlanırken hata oluştu:\n{ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
